// Fill out your copyright notice in the Description page of Project Settings.

#include "EquipmentSwitchMotion.h"



class AMordhauEquipment* UEquipmentSwitchMotion::GetSwitchingTo()
{
	return nullptr;
}
