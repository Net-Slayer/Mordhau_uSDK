// Fill out your copyright notice in the Description page of Project Settings.

#include "InteractionComponent.h"




void UInteractionComponent::UnHighlight()
{}
void UInteractionComponent::InteractionStart(class AAdvancedCharacter* Character)
{}
void UInteractionComponent::InteractionEnd()
{}
void UInteractionComponent::Highlight()
{}
bool UInteractionComponent::CanInteract(class AAdvancedCharacter* Character)
{
	return 1;
}