// Fill out your copyright notice in the Description page of Project Settings.

#include "SubField.h"


// Sets default values
class AMasterField* ASubField::GetMaster()
{
	return nullptr;
}

