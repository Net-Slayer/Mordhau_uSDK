// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "MordhauWeapon.h"
#include "WheeledVehicleAnimInstance.generated.h"

/**
 * 
 */
UCLASS()
class MORDHAU_API UWheeledVehicleAnimInstance : public UObject
{
	GENERATED_BODY()
	
	
	
	
};
