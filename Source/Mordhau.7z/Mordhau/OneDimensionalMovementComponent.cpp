// Fill out your copyright notice in the Description page of Project Settings.

#include "OneDimensionalMovementComponent.h"




void UOneDimensionalMovementComponent::SetMovementLine(const struct FVector& NewLineStart, const struct FVector& NewLineEnd)
{}