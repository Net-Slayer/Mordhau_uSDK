// Fill out your copyright notice in the Description page of Project Settings.

#include "GameModeMetadata.h"




class UGameModeMetadata* UGameModeMetadata::GetDefaultObject(class UClass* MetadataClass)
{
	return nullptr;
}