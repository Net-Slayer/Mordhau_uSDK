// Fill out your copyright notice in the Description page of Project Settings.

#include "AdvancedCharacterAnimInstance.h"




void UAdvancedCharacterAnimInstance::OnFootstep(int Limb, int SurfaceType)
{}
void UAdvancedCharacterAnimInstance::DoFootstep(int Limb)
{}