// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "AdvancedCharacterAnimInstance.h"
#include "CompoundVehicleAnimInstance.generated.h"

/**
 * 
 */
UCLASS()
class MORDHAU_API UCompoundVehicleAnimInstance : public UAdvancedCharacterAnimInstance
{
	GENERATED_BODY()
	
	
	
	
};
