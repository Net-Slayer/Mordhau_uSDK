// Fill out your copyright notice in the Description page of Project Settings.

#include "EnvQueryTest_Obectives.h"




