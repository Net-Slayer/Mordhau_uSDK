// Fill out your copyright notice in the Description page of Project Settings.

#include "ControlPoint.h"


// Sets default values

//void AControlPoint::UpdateVisuals()
//{
//
//}
//void AControlPoint::UpdateUIWidgets()
//{
//
//}
//void AControlPoint::UpdateUIMaterialInstance()
//{
//
//}
//void AControlPoint::UpdatePresenceNumbers()
//{
//
//}
//void AControlPoint::UpdateCaptureProgress(float DeltaTime)
//{}
void AControlPoint::SetCaptureProgress(float NewProgress, uint8 NewCaptor, bool bAwardScore)
{}
//void AControlPoint::EnemyLostPrerequisites()
//{
//
//}
//void AControlPoint::EnemyGainedPrerequisites()
//{
//
//}
bool AControlPoint::CanCapture(uint8 Team)
{
	return 1;
}

void AControlPoint::OnStoppedFlashing_Implementation()
{

}
void AControlPoint::OnStartedFlashing_Implementation()
{

}
void AControlPoint::OnRep_CaptureProgress_Implementation()
{

}
void AControlPoint::OnRep_OwningTeam_Implementation()
{

}
void AControlPoint::OnRep_CapturingTeam_Implementation()
{

}
void AControlPoint::OnOwningTeamChanged_Implementation()
{

}
void AControlPoint::OnCapturingTeamChanged_Implementation()
{

}
void AControlPoint::OnCaptureAreaEndOverlap_Implementation(class UPrimitiveComponent* OverlappedComp, class AActor* Other, class UPrimitiveComponent* OtherComp, int OtherBodyIndex)
{

}
void AControlPoint::OnCaptureAreaBeginOverlap_Implementation(class UPrimitiveComponent* OverlappedComp, class AActor* Other, class UPrimitiveComponent* OtherComp, int OtherBodyIndex, bool bFromSweep, const struct FHitResult& SweepResult)
{

}

