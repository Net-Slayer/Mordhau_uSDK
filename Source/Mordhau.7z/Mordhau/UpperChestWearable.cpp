// Fill out your copyright notice in the Description page of Project Settings.

#include "UpperChestWearable.h"




int UUpperChestWearable::GetShouldersWearablesNum()
{
	return 1;
	}
class UClass* UUpperChestWearable::GetShouldersWearable(int Index)
	{
	return nullptr;
	}
int UUpperChestWearable::GetLowerChestWearablesNum()
{
	return 1;
	}
class UClass* UUpperChestWearable::GetLowerChestWearable(int Index)
	{
	return nullptr;
	}
int UUpperChestWearable::GetArmsWearablesNum()
{
	return 1;
	}
class UClass* UUpperChestWearable::GetArmsWearable(int Index)
{
	return nullptr;
}