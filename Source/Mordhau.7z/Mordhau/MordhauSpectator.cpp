// Fill out your copyright notice in the Description page of Project Settings.

#include "MordhauSpectator.h"




void AMordhauSpectator::TertiarySpectatorAction()
{}
void AMordhauSpectator::SwitchToFreeCam()
{}
void AMordhauSpectator::SecondarySpectatorAction()
{}
void AMordhauSpectator::PrimarySpectatorAction()
{}
bool AMordhauSpectator::IsWatchingOwnDeath()
{
	return 1;
}
