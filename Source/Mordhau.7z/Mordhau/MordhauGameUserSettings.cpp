// Fill out your copyright notice in the Description page of Project Settings.

#include "MordhauGameUserSettings.h"




bool UMordhauGameUserSettings::ShouldShowWatermark()
{

return 1;
}
bool UMordhauGameUserSettings::ShouldShowTips()
{

return 1;
}
bool UMordhauGameUserSettings::ShouldShowTargetInfo()
{

return 1;
}
bool UMordhauGameUserSettings::ShouldShowStatusBar()
{

return 1;
}
bool UMordhauGameUserSettings::ShouldShowSpawnInfo()
{

return 1;
}
bool UMordhauGameUserSettings::ShouldShowScoreFeed()
{

return 1;
}
bool UMordhauGameUserSettings::ShouldShowObservedDelay()
{

return 1;
}
bool UMordhauGameUserSettings::ShouldShowMatchmakingOverride()
{

return 1;
}
bool UMordhauGameUserSettings::ShouldShowMatchmakingDebug()
{

return 1;
}
bool UMordhauGameUserSettings::ShouldShowKillFeed()
{

return 1;
}
bool UMordhauGameUserSettings::ShouldShowKilledBy()
{

return 1;
}
bool UMordhauGameUserSettings::ShouldShowHUD()
{

return 1;
}
bool UMordhauGameUserSettings::ShouldShowHitMarker()
{

return 1;
}
bool UMordhauGameUserSettings::ShouldShowEquipment()
{

return 1;
}
bool UMordhauGameUserSettings::ShouldShowEmotesMenu()
{

return 1;
}
bool UMordhauGameUserSettings::ShouldShowCrosshair()
{

return 1;
}
bool UMordhauGameUserSettings::ShouldShowChatBox()
{

return 1;
}
bool UMordhauGameUserSettings::ShouldShowBlood()
{


return 1;
}
bool UMordhauGameUserSettings::ShouldShowAnnouncements()
{

return 1;
}
bool UMordhauGameUserSettings::ShouldShowAmmo()
{

return 1;
}
bool UMordhauGameUserSettings::ShouldQuickSpawn()
{

return 1;
}
bool UMordhauGameUserSettings::ShouldDrawTracers()
{

return 1;
}

void UMordhauGameUserSettings::SetVideoVolume(float NewVolume)
{}
void UMordhauGameUserSettings::SetTracersStayTime(float NewStayTime)
{}
void UMordhauGameUserSettings::SetThirdPersonDeathcamera(int NewThirdPersonDeathCamera)
{}
void UMordhauGameUserSettings::SetShowTips(int NewShowTips)
{}
void UMordhauGameUserSettings::SetShowTargetInfo(int NewShowTargetInfo)
{}
void UMordhauGameUserSettings::SetShowStatusBar(int NewShowStatusBar)
{}
void UMordhauGameUserSettings::SetShowSpawnInfo(int NewShowSpawnInfo)
{}
void UMordhauGameUserSettings::SetShowScoreFeed(int NewShowScoreFeed)
{}
void UMordhauGameUserSettings::SetShowObservedDelay(int NewShowObservedDelay)
{}
void UMordhauGameUserSettings::SetShowMatchmakingOverride(int NewShowMatchmakingOverride)
{}
void UMordhauGameUserSettings::SetShowMatchmakingDebug(int NewShowMatchmakingDebug)
{}
void UMordhauGameUserSettings::SetShowKillFeed(int NewShowKillFeed)
{}
void UMordhauGameUserSettings::SetShowKilledBy(int NewShowKilledBy)
{}
void UMordhauGameUserSettings::SetShowHitMarker(int NewShowHitMarker)
{}
void UMordhauGameUserSettings::SetShowEquipment(int NewShowEquipment)
{}
void UMordhauGameUserSettings::SetShowEmotesMenu(int NewEmotesMenu)
{}
void UMordhauGameUserSettings::SetShowCrosshair(int NewShowCrosshair)
{}
void UMordhauGameUserSettings::SetShowChatBox(int NewShowChatBox)
{}
void UMordhauGameUserSettings::SetShowAnnouncements(int NewShowAnnouncements)
{}
void UMordhauGameUserSettings::SetShowAmmo(int NewShowAmmo)
{}
void UMordhauGameUserSettings::SetServerBrowserServerName(const FString& NewServerName)
{}
void UMordhauGameUserSettings::SetServerBrowserNotFull(bool bNewNotFull)
{}
void UMordhauGameUserSettings::SetServerBrowserNoPassword(bool bNewNoPassword)
{}
void UMordhauGameUserSettings::SetServerBrowserMaxPing(int NewMaxPing)
{}
void UMordhauGameUserSettings::SetServerBrowserHasPlayers(bool bNewHasPlayers)
{}
void UMordhauGameUserSettings::SetServerBrowserGameMode(const FString& NewGameMode)
{}
void UMordhauGameUserSettings::SetScreenSpaceReflections(int NewScreenSpaceReflections)
{}
void UMordhauGameUserSettings::SetScreenPercentage(float NewScreenPercentage)
{}
void UMordhauGameUserSettings::SetRagdollStayTime(float NewTime)
{}
void UMordhauGameUserSettings::SetRagdollFidelity(int NewFidelity)
{}
void UMordhauGameUserSettings::SetQuickSpawn(int NewQuickSpawn)
{}
void UMordhauGameUserSettings::SetNoTeamColorsOnGear(int NewNoTeamColorsOnGear)
{}
void UMordhauGameUserSettings::SetMusicVolume(float NewVolume)
{}
void UMordhauGameUserSettings::SetMouseSmoothing(float NewSmoothing)
{}
void UMordhauGameUserSettings::SetMotionBlur(float NewMotionBlur)
{}
void UMordhauGameUserSettings::SetMaxRagdolls(int NewMax)
{}
//void UMordhauGameUserSettings::SetMatchmakingRegion(EServerRegion NewRegion)
//{}
void UMordhauGameUserSettings::SetMatchmakingGameModes(TArray<FString> NewGameModes)
{}
void UMordhauGameUserSettings::SetMasterVolume(float NewVolume)
{}
void UMordhauGameUserSettings::SetLensFlares(int NewLensFlares)
{}
void UMordhauGameUserSettings::SetLanguage(const FString& NewLanguage)
{}
void UMordhauGameUserSettings::SetIndirectCapsuleShadows(int NewShadows)
{}
void UMordhauGameUserSettings::SetHideWatermark(int NewHideWatermark)
{}
void UMordhauGameUserSettings::SetHideHUD(int NewHideHUD)
{}
void UMordhauGameUserSettings::SetHideDefaultLoadouts(int NewHideDefaultLoadouts)
{}
void UMordhauGameUserSettings::SetHeadbob(float NewHeadbob)
{}
void UMordhauGameUserSettings::SetGore(int NewGore)
{}
void UMordhauGameUserSettings::SetGamma(float NewGamma)
{}
void UMordhauGameUserSettings::SetFriendlyMarkers(int NewFriendlyMarkers)
{}
void UMordhauGameUserSettings::SetFieldOfView(float NewFOV)
{}
void UMordhauGameUserSettings::SetEffectsVolume(float NewVolume)
{}
void UMordhauGameUserSettings::SetDrawTracers(int NewDrawTracers)
{}
void UMordhauGameUserSettings::SetCrosshairType(int NewCrosshairType)
{}
void UMordhauGameUserSettings::SetCharacterFidelity(int NewFidelity)
{}
void UMordhauGameUserSettings::SetCharacterCloth(int NewCharacterCloth)
{}
void UMordhauGameUserSettings::SetCameraDistance(float NewCameraDistance)
{}
void UMordhauGameUserSettings::SetBloom(float NewBloom)
{}
void UMordhauGameUserSettings::SetAntiAliasing(int NewAntiAliasing)
{}
void UMordhauGameUserSettings::SetAmbientOcclusion(int NewAmbientOcclusion)
{}

float UMordhauGameUserSettings::GetVideoVolume()
{
	return 1;
}
struct FVector2D UMordhauGameUserSettings::GetTracersStayTimeLimits()
{
	return { 1, 1 };
}
float UMordhauGameUserSettings::GetTracersStayTime()
{
	return 1;
}
int UMordhauGameUserSettings::GetThirdPersonDeathCamera()
{
	return 1;
}
int UMordhauGameUserSettings::GetShowTips()
{
	return 1;
}
int UMordhauGameUserSettings::GetShowTargetInfo()
{
	return 1;
}
int UMordhauGameUserSettings::GetShowStatusBar()
{
	return 1;
}
int UMordhauGameUserSettings::GetShowSpawnInfo()
{
	return 1;
}
int UMordhauGameUserSettings::GetShowScoreFeed()
{
	return 1;
}
int UMordhauGameUserSettings::GetShowObservedDelay()
{
	return 1;
}
int UMordhauGameUserSettings::GetShowKillFeed()
{
	return 1;
}
int UMordhauGameUserSettings::GetShowKilledBy()
{
	return 1;
}
int UMordhauGameUserSettings::GetShowHitMarker()
{
	return 1;
}
int UMordhauGameUserSettings::GetShowEquipment()
{
	return 1;
}
int UMordhauGameUserSettings::GetShowEmotesMenu()
{
	return 1;
}
int UMordhauGameUserSettings::GetShowCrosshair()
{
	return 1;
}
int UMordhauGameUserSettings::GetShowChatBox()
{
	return 1;
}
int UMordhauGameUserSettings::GetShowAnnouncements()
{
	return 1;
}
int UMordhauGameUserSettings::GetShowAmmo()
{
	return 1;
}
FString UMordhauGameUserSettings::GetServerBrowserServerName()
{
	return "1";
}
bool UMordhauGameUserSettings::GetServerBrowserNotFull()
{
	return 1;
}
bool UMordhauGameUserSettings::GetServerBrowserNoPassword()
{
	return 1;
}
int UMordhauGameUserSettings::GetServerBrowserMaxPing()
{
	return 1;
}
bool UMordhauGameUserSettings::GetServerBrowserHasPlayers()
{
	return 1;
}
FString UMordhauGameUserSettings::GetServerBrowserGameMode()
{
	return "1";
}
int UMordhauGameUserSettings::GetScreenSpaceReflections()
{
	return 1;
}
struct FVector2D UMordhauGameUserSettings:: GetScreenPercentageLimits()
{
	return {1, 1};
}
float UMordhauGameUserSettings::GetScreenPercentage()
{
	return 1;
}
float UMordhauGameUserSettings::GetRagdollStayTimeLimit()
{
	return 1;
}
float UMordhauGameUserSettings::GetRagdollStayTime()
{
	return 1;
}
int UMordhauGameUserSettings::GetRagdollFidelity()
{
	return 1;
}
int UMordhauGameUserSettings::GetQuickSpawn()
{
	return 1;
}
int UMordhauGameUserSettings::GetNoTeamColorsOnGear()
{
	return 1;
}
float UMordhauGameUserSettings::GetMusicVolume()
{
	return 1;
}
struct FVector2D UMordhauGameUserSettings:: GetMouseSmoothingLimits()
{
	return {1, 1};
}
float UMordhauGameUserSettings::GetMouseSmoothing()
{
	return 1;
}
struct FVector2D UMordhauGameUserSettings:: GetMotionBlurLimits()
{
	return {1, 1};
}
float UMordhauGameUserSettings::GetMotionBlur()
{
	return 1;
}
int UMordhauGameUserSettings::GetMaxRagdollsLimit()
{
	return 1;
}
int UMordhauGameUserSettings::GetMaxRagdolls()
{
	return 1;
}
//EServerRegion GetMatchmakingRegion()

void UMordhauGameUserSettings::GetMatchmakingGameModes(TArray<FString>& Modes)
{

}
float UMordhauGameUserSettings::GetMasterVolume()
{
	return 1;
}
int UMordhauGameUserSettings::GetLensFlares()
{
	return 1;
}
FString UMordhauGameUserSettings::GetLanguage()
{
	return "1";
}
int UMordhauGameUserSettings::GetIndirectCapsuleShadows()
{
	return 1;
}
int UMordhauGameUserSettings::GetHideWatermark()
{
	return 1;
}
int UMordhauGameUserSettings::GetHideHUD()
{
	return 1;
}
int UMordhauGameUserSettings::GetHideDefaultLoadouts()
{
	return 1;
}
struct FVector2D UMordhauGameUserSettings:: GetHeadbobLimits()
{
	return {1, 1};
}
float UMordhauGameUserSettings::GetHeadbob()
{
	return 1;
}
int UMordhauGameUserSettings::GetGore()
{
	return 1;
}
struct FVector2D UMordhauGameUserSettings:: GetGammaLimits()
{
	return {1, 1};
}
float UMordhauGameUserSettings::GetGamma()
{
	return 1;
}
int UMordhauGameUserSettings::GetFriendlyMarkers()
{
	return 1;
}
struct FVector2D UMordhauGameUserSettings:: GetFrameRateLimits()
{
	return {1, 1};
}
struct FVector2D UMordhauGameUserSettings:: GetFieldOfViewLimits()
{
	return {1, 1};
}
float UMordhauGameUserSettings::GetFieldOfView()
{
	return 1;
}
float UMordhauGameUserSettings::GetEffectsVolume()
{
	return 1;
}
int UMordhauGameUserSettings::GetDrawTracers()
{
	return 1;
}
float UMordhauGameUserSettings::GetCurrentMotionBlur()
{
	return 1;
}
float UMordhauGameUserSettings::GetCurrentGamma()
{
	return 1;
}
float UMordhauGameUserSettings::GetCurrentBloom()
{
	return 1;
}
int UMordhauGameUserSettings::GetCrosshairType()
{
	return 1;
}
int UMordhauGameUserSettings::GetCharacterFidelity()
{
	return 1;
}
int UMordhauGameUserSettings::GetCharacterCloth()
{
	return 1;
}
struct FVector2D UMordhauGameUserSettings:: GetCameraDistanceLimits()
{
	return {1, 1};
}
float UMordhauGameUserSettings::GetCameraDistance()
{
	return 1;
}
struct FVector2D UMordhauGameUserSettings:: GetBloomLimits()
{
	return {1, 1};
}
float UMordhauGameUserSettings::GetBloom()
{
	return 1;
}
//void UMordhauGameUserSettings::GetAvailableLanguages(TArray<FString> AvailableLanguages)
//{
//
//}
int UMordhauGameUserSettings::GetAntiAliasing()
{
	return 1;
}
int UMordhauGameUserSettings::GetAmbientOcclusion()
{
	return 1;
}
int UMordhauGameUserSettings::GetActualCrosshairType()
{
	return 1;
}