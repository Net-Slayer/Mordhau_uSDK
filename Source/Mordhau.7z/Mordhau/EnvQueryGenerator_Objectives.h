// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "EnvironmentQuery/EnvQueryGenerator.h"
#include "EnvQueryGenerator_Objectives.generated.h"

/**
 * 
 */
UCLASS()
class MORDHAU_API UEnvQueryGenerator_Objectives : public UEnvQueryGenerator
{
	GENERATED_BODY()
	
	
	
	
};
