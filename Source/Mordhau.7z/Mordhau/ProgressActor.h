// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "MordhauActor.h"
#include "ProgressActor.generated.h"

/**
 * 
 */
UCLASS()
class MORDHAU_API AProgressActor : public AMordhauActor
{
	GENERATED_BODY()
	
	
	
	
};
