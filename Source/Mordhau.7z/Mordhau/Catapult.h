// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "MordhauCompoundVehicle.h"
#include "Catapult.generated.h"

/**
 * 
 */
UCLASS()
class MORDHAU_API ACatapult : public AMordhauCompoundVehicle
{
	GENERATED_BODY()
	
	
	
	
};
