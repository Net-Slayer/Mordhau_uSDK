// Fill out your copyright notice in the Description page of Project Settings.

#include "UpdateMordhauSession.h"




class UUpdateMordhauSession* UUpdateMordhauSession::UpdateMordhauSession(const struct FServerSearchResult& Session)
{
	return nullptr;
}