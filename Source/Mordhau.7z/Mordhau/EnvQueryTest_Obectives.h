// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "EnvironmentQuery/EnvQueryTest.h"
#include "EnvQueryTest_Obectives.generated.h"

/**
 * 
 */
UCLASS()
class MORDHAU_API UEnvQueryTest_Obectives : public UEnvQueryTest
{
	GENERATED_BODY()
	
	
	
	
};
