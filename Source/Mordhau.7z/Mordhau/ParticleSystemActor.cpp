// Fill out your copyright notice in the Description page of Project Settings.

#include "ParticleSystemActor.h"


// Sets default values
void AParticleSystemActor::SparseTick()
{}

