// Fill out your copyright notice in the Description page of Project Settings.

#include "AdvancedCharacterMovement.h"
#include "UnrealNetwork.h"


//void UAdvancedCharacterMovement::GetLifetimeReplicatedProps(TArray< FLifetimeProperty > & OutLifetimeProps) const
//{
//	Super::GetLifetimeReplicatedProps(OutLifetimeProps);
//
//	DOREPLIFETIME(UAdvancedCharacterMovement, LastFallingCheckVelocityZ)
//	DOREPLIFETIME(UAdvancedCharacterMovement, bUseMordhauRotationInterpMode)
//	DOREPLIFETIME(UAdvancedCharacterMovement, MordhauRotationSmoothStartTime)
//	DOREPLIFETIME(UAdvancedCharacterMovement, StillTimeWhileRagdollFalling)
//	DOREPLIFETIME(UAdvancedCharacterMovement, PerchRadiusThresholdRagdollFalling)
//	DOREPLIFETIME(UAdvancedCharacterMovement, MinVelocityForFallDamage)
//	DOREPLIFETIME(UAdvancedCharacterMovement, FallDamageOffset)
//	DOREPLIFETIME(UAdvancedCharacterMovement, FallDamageFactor)
//	DOREPLIFETIME(UAdvancedCharacterMovement, RagdollMinVelocityForFallDamage)
//	DOREPLIFETIME(UAdvancedCharacterMovement, RagdollFallDamageOffset)
//	DOREPLIFETIME(UAdvancedCharacterMovement, RagdollFallDamageFactor)
//	DOREPLIFETIME(UAdvancedCharacterMovement, bReverseBackwardsTurning)
//	DOREPLIFETIME(UAdvancedCharacterMovement, bUsePendingRotationToOrientMovement)
//	DOREPLIFETIME(UAdvancedCharacterMovement, PendingTurnValue)
//	DOREPLIFETIME(UAdvancedCharacterMovement, bIgnoreMovementInput)
//	DOREPLIFETIME(UAdvancedCharacterMovement, AuthNetSmoothTime)
//	DOREPLIFETIME(UAdvancedCharacterMovement, AuthNetMaxSmoothDist)
//	DOREPLIFETIME(UAdvancedCharacterMovement, bDisableAuthNetSmoothing)
//	DOREPLIFETIME(UAdvancedCharacterMovement, SkipPredictionForAnimTickSkipOrGreater)
//
//
//}