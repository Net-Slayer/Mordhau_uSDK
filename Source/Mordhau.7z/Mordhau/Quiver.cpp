// Fill out your copyright notice in the Description page of Project Settings.

#include "Quiver.h"




class UStaticMesh* UQuiver::FindAppropriateQuiverMesh(uint8 Ammo, uint8 MaxAmmo)
{
	return nullptr;
}