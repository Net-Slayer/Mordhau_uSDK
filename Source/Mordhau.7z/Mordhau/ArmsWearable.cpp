// Fill out your copyright notice in the Description page of Project Settings.

#include "ArmsWearable.h"





int UArmsWearable::GetHandsWearablesNum()
{
	return 1;
}
class UClass* UArmsWearable::GetHandsWearable(int Index)
{
	return nullptr;
}