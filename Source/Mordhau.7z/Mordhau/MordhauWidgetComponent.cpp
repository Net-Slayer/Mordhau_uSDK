// Fill out your copyright notice in the Description page of Project Settings.

#include "MordhauWidgetComponent.h"




void UMordhauWidgetComponent::SetPlayerStateAlwaysSee(class APlayerState* PlayerState)
{}