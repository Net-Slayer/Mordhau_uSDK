// Fill out your copyright notice in the Description page of Project Settings.

#include "HeadWearable.h"


int UHeadWearable::GetCoifWearablesNum()
{
	return 1;
}
class UClass* UHeadWearable::GetCoifWearable(int Index)
	{
	return nullptr;
	}


