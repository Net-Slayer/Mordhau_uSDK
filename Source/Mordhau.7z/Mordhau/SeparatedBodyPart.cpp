// Fill out your copyright notice in the Description page of Project Settings.

#include "SeparatedBodyPart.h"


// Sets default values
bool ASeparatedBodyPart::IsDismembered(const FName& bone)
{
	return 1;
}

bool ASeparatedBodyPart::IsPartiallyDismembered()
{
	return 1;
}
