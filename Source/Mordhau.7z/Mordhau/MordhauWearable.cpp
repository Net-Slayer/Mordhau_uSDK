// Fill out your copyright notice in the Description page of Project Settings.

#include "MordhauWearable.h"
#include "UnrealNetwork.h"


//void UMordhauWearable::GetLifetimeReplicatedProps(TArray< FLifetimeProperty > & OutLifetimeProps) const
//{
//	Super::GetLifetimeReplicatedProps(OutLifetimeProps);
//	DOREPLIFETIME(UMordhauWearable, Metallic)
//		DOREPLIFETIME(UMordhauWearable, Roughness)
//		DOREPLIFETIME(UMordhauWearable, MetalAlbedoDarken)
//		DOREPLIFETIME(UMordhauWearable, PDO)
//		DOREPLIFETIME(UMordhauWearable, EmblemRotation)
//		DOREPLIFETIME(UMordhauWearable, bHasEmblem)
//		DOREPLIFETIME(UMordhauWearable, bMuffleVoice)
//		DOREPLIFETIME(UMordhauWearable, bTreatAsMaster)
//		DOREPLIFETIME(UMordhauWearable, bHideIn1P)
//		DOREPLIFETIME(UMordhauWearable, bHideEars)
//		DOREPLIFETIME(UMordhauWearable, bHideHair)
//		DOREPLIFETIME(UMordhauWearable, bHideBeard)
//		DOREPLIFETIME(UMordhauWearable, bHideNose)
//		DOREPLIFETIME(UMordhauWearable, bHideLeftHand)
//		DOREPLIFETIME(UMordhauWearable, bHideRightHand)
//		DOREPLIFETIME(UMordhauWearable, bHideLeftFoot)
//		DOREPLIFETIME(UMordhauWearable, bHideRightFoot)
//		DOREPLIFETIME(UMordhauWearable, bHideLeftLeg)
//		DOREPLIFETIME(UMordhauWearable, bHideRightLeg)
//		DOREPLIFETIME(UMordhauWearable, bHideChest)
//		DOREPLIFETIME(UMordhauWearable, bHideLeftArm)
//		DOREPLIFETIME(UMordhauWearable, bHideRightArm)
//		DOREPLIFETIME(UMordhauWearable, bIsAuxiliaryConsideredBody)
//		DOREPLIFETIME(UMordhauWearable, bAuxiliaryWantsMaterialInstance)
//		DOREPLIFETIME(UMordhauWearable, bAuxiliary1POverrideWantsMaterialInstance)
//		DOREPLIFETIME(UMordhauWearable, VertexCameraDisplacement)
//		DOREPLIFETIME(UMordhauWearable, CharacterPointCost)
//		DOREPLIFETIME(UMordhauWearable, ArmorClass)
//		DOREPLIFETIME(UMordhauWearable, bIsAllowedForPeasants)
//		DOREPLIFETIME(UMordhauWearable, SpeedFactor)
//		DOREPLIFETIME(UMordhauWearable, AccelerationFactor)
//		DOREPLIFETIME(UMordhauWearable, Pattern)
//		DOREPLIFETIME(UMordhauWearable, Colors)
//		DOREPLIFETIME(UMordhauWearable, ColorTables)
//		DOREPLIFETIME(UMordhauWearable, bIgnoreTeamColor1)
//		DOREPLIFETIME(UMordhauWearable, bIgnoreTeamColor2)
//}