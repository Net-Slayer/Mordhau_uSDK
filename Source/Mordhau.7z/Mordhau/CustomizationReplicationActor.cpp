// Fill out your copyright notice in the Description page of Project Settings.

#include "CustomizationReplicationActor.h"
#include "UnrealNetwork.h"


void ACustomizationReplicationActor::UpdateCharacterProfile(class AMordhauCharacter* Character)
{

}
void ACustomizationReplicationActor::UnregisterCharacter(class AMordhauCharacter* Character)
{

}
void ACustomizationReplicationActor::TriggerUpdateIfUpToDate()
{

}
void ACustomizationReplicationActor::RegisterCharacter(class AMordhauCharacter* Character)
{

}
void ACustomizationReplicationActor::OnRep_WearablePattern_Implementation()
{

}
void ACustomizationReplicationActor::OnRep_WearableId_Implementation()
{

}
void ACustomizationReplicationActor::OnRep_WearableColor2_Implementation()
{

}
void ACustomizationReplicationActor::OnRep_WearableColor1_Implementation()
{

}
void ACustomizationReplicationActor::OnRep_SkillsCustomization_Implementation()
{

}
void ACustomizationReplicationActor::OnRep_FaceBonesTranslate_Implementation()
{

}
void ACustomizationReplicationActor::OnRep_FaceBonesScale_Implementation()
{

}
void ACustomizationReplicationActor::OnRep_FaceBonesRotate_Implementation()
{

}
void ACustomizationReplicationActor::OnRep_DefaultEquipmentId_Implementation()
{

}
void ACustomizationReplicationActor::OnRep_AppearanceCustomization_Implementation()
{

}
bool ACustomizationReplicationActor::IsUpToDate()
{
	return 1;
}
void ACustomizationReplicationActor::AssignDataFromProfile(const struct FCharacterProfile& Profile)
{}