// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "MordhauWeapon.h"
#include "VirtualWeapon.generated.h"

/**
 * 
 */
UCLASS()
class MORDHAU_API AVirtualWeapon : public AMordhauWeapon
{
	GENERATED_BODY()
	
	
	
	
};
