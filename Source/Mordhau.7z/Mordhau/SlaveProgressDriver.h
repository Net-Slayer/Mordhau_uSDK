// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "ProgressDriver.h"
#include "SlaveProgressDriver.generated.h"

/**
 * 
 */
UCLASS()
class MORDHAU_API ASlaveProgressDriver : public AProgressDriver
{
	GENERATED_BODY()
	
	
	
	
};
