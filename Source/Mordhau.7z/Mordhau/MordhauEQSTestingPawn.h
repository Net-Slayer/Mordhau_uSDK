// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "EnvironmentQuery/EQSTestingPawn.h"
#include "MordhauEQSTestingPawn.generated.h"

/**
 * 
 */
UCLASS()
class MORDHAU_API AMordhauEQSTestingPawn : public AEQSTestingPawn
{
	GENERATED_BODY()
	
	
	
	
};
