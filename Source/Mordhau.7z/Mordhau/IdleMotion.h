// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "MordhauMotion.h"
#include "IdleMotion.generated.h"

/**
 * 
 */
UCLASS(Blueprintable)
class MORDHAU_API UIdleMotion : public UMordhauMotion
{
	GENERATED_BODY()
	
	
	
	
};
