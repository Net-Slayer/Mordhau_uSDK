// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/LocalMessage.h"
#include "MordhauEngineMessage.generated.h"

/**
 * 
 */
UCLASS(Blueprintable)
class MORDHAU_API UMordhauEngineMessage : public ULocalMessage
{
	GENERATED_BODY()
	
	
	
	
};
