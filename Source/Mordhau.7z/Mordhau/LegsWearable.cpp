// Fill out your copyright notice in the Description page of Project Settings.

#include "LegsWearable.h"





int ULegsWearable::GetFeetWearablesNum()
{
	return 1;
}
class UClass* ULegsWearable::GetFeetWearable(int Index)
{
	return nullptr;
}