// Fill out your copyright notice in the Description page of Project Settings.

#include "EnvironmentMovable.h"


// Sets default values

void AEnvironmentMovable::InitializeMovable(class USceneComponent* InSwayingComponent, const struct FVector& InRollPitchYawFrequency, const struct FVector& InRollPitchYawMagnitude, const struct FVector& InRollPitchYawSpeed)
{}