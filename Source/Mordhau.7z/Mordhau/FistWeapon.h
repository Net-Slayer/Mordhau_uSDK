// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "VirtualWeapon.h"
#include "FistWeapon.generated.h"

/**
 * 
 */
UCLASS()
class MORDHAU_API AFistWeapon : public AVirtualWeapon
{
	GENERATED_BODY()
	
	
	
	
};
