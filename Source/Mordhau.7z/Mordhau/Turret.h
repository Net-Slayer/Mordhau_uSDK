// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "AdvancedCharacter.h"
#include "Turret.generated.h"

/**
 * 
 */
UCLASS()
class MORDHAU_API ATurret : public AAdvancedCharacter
{
	GENERATED_BODY()
	
	
	
	
};
