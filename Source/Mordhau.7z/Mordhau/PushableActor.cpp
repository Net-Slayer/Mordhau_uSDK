// Fill out your copyright notice in the Description page of Project Settings.

#include "PushableActor.h"





void APushableActor::SetProgress(float NewProgress)
{
}
void APushableActor::OnRep_Progress()
{
	}
//void APushableActor::OnProgressUpdated(float OldProgress)
//{
//}
